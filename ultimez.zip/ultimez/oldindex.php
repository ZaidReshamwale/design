<?php
include ("head.php");

?>
<!DOCTYPE html>
<html>
<head>
	<title>User Login</title>
</head>
<style type="text/css">

	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@592&family=Sriracha&display=swap" rel="stylesheet">
</style>
<body class="col d-flex justify-content-center">

<div class="container" style="top:270px;bottom: 270px;">
  <h2>USER LOGIN</h2>
  <div class="login-box">
  <div class="row">
  <div class="col-md-11">
  <form action="login.php" class="was-validated" method="POST">
    <div class="form-group">
      <label for="uemail">Login ID:</label>
      <input type="email" class="form-control" id="uemail" placeholder="Enter username" name="uemail" required>
      <div class="valid-feedback">Valid.</div>
      <div class="invalid-feedback">Please fill out this field.</div>
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="upassword" placeholder="Enter password" name="upassword"    required>
      
    </div>
    <!-- <div class="form-group form-check">
      <label class="form-check-label">
        <input class="form-check-input" type="checkbox" name="remember" required> I agree the terms
        <div class="valid-feedback">Valid.</div>
        <div class="invalid-feedback">Check this checkbox to continue.</div>
      </label>
    </div>
     --><button type="submit" class="btn btn-primary">Login</button>
 <button type="submit" class="btn btn-danger" id="signup" onclick="location.href='regsi.php';">New User?</button>
  </form>


</div>
</div>
</body>
</html>

