

<?php
session_start();
require 'connection.php';
// redirecting user after login


$conn = Connect();

$ufullname = $conn->real_escape_string($_POST['ufullname']);
$uemail = $conn->real_escape_string($_POST['uemail']);
$uphone = $conn->real_escape_string($_POST['uphone']);
$upassword = $conn->real_escape_string($_POST['upassword']);
$username = $conn-> real_escape_string($_POST['username']);

// $username = $uemail[1];
// $username = intval($uemail[2]);
$username = preg_replace('/([^@]*).*/', '$1', $uemail);

  
$sql= "SELECT * FROM `user` WHERE uemail = '$uemail'";
$result = mysqli_query ($conn, $sql);
if(mysqli_num_rows($result)==1)
   			{
      			echo '<script>alert("User Email already exists");
      			window.location.href ="regsi.php"</script>';
    		} else {
    		// $shop_password = md5($shop_password);
$query = "INSERT into user(ufullname,uemail,uphone,upassword,username) VALUES('" . $ufullname . "','" . $uemail . "','" . $uphone . "','" . $upassword . "','" . $username . "' )";
$username = preg_replace('/([^@]*).*/', '$1', $uemail);

$success = $conn->query($query);


	echo '<script>alert("Registration Successfull");
	window.location.href ="index.php";</script>';


if (!$success){

	die("Couldnt enter data: ".$conn->error);
}
}
$conn->close();

?>


