

<?php
session_start();
require 'connection.php';
// redirecting user after login


$conn = Connect();

$uemail = $conn->real_escape_string($_POST['uemail']);
// $uemail = $conn->real_escape_string($_POST['uemail']);
// $uphone = $conn->real_escape_string($_POST['uphone']);
$upassword = $conn->real_escape_string($_POST['upassword']);


$sql= "SELECT * FROM `user` WHERE uemail = '$uemail' && upassword = '$upassword'";
$result = mysqli_query ($conn, $sql);
if(mysqli_num_rows($result)==1)
   			{
   				 $data=mysqli_fetch_assoc($result);
   		             startsession("User",$data);
   				// session started here
   				// $_SESSION['ufullname']=$ufullname;
   				// $_SESSION['uemail']=$uemail;
   				// $_SESSION['uphone']=$uphone; 
      			echo '<script>alert("login Successfully");
	window.location.href ="dboard.php";</script>';
    		} else {
	echo '<script>alert("Invalid Username and password");
	window.location.href ="index.php";</script>';
    		


}
$conn->close();

 function startsession($key,$data)
{
	session_start();
	$_SESSION[$key]=$data;
	$response['Success']='true';
	$response['Message']=" session started";
	return $response; 
}

?>


