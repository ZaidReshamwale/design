<?php
include ("head.php");

?>
<!DOCTYPE html>
<html>
<head>
	<title>User Login</title>
</head>
<body class="col d-flex justify-content-center">

<div class="container" style="top:270px;bottom: 270px;">
  <h2>USER REGISTARTION</h2>
  <div class="row">
  <div class="col-md-10">
  <form action="registration.php" class="was-validated" method="POST">
    <div class="form-group">
      <label for="uname">User FullName:</label>
      <input type="text" class="form-control" id="ufullname" placeholder="Enter FullName" name="ufullname" required>
      <div class="valid-feedback">Valid.</div>
      <div class="invalid-feedback">Please fill out this field.</div>
    </div>
    <div class="form-group">
     <label for="uemail">Email:</label>
      <input type="email" class="form-control" id="uemail" placeholder="Enter Email" name="uemail" required>
      <div class="valid-feedback">Valid.</div>
      <div class="invalid-feedback">Please fill out this field.</div>
    
      </div>
      <div class="form-group">
     <label for="upassword">Phone No:</label>
      <input type="text" class="form-control" id="uphone" placeholder="Enter Phone Number" name="uphone" maxlength="10" pattern="[0-9]{10}" required>
      <div class="valid-feedback">Valid.</div>
      <div class="invalid-feedback">Please fill out this field.</div>
    </div>

    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="upassword" placeholder="Enter password" name="upassword"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}"  required>
      <div class="valid-feedback">Valid.</div>
      <div class="invalid-feedback">Please fill out this field.</div>
    </div>

    <!-- <
    <div class="form-group form-check">
      <label class="form-check-label">
        <input class="form-check-input" type="checkbox" name="remember" required> I agree the terms
        <div class="valid-feedback">Valid.</div>
        <div class="invalid-feedback">Check this checkbox to continue.</div>
      </label>
    </div>
     -->
     <button type="submit" class="btn btn-success  btn-block" id="btsignup" >
  Register
</button>

  </form>
  
</div>


</body>
</html>

