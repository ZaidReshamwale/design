-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 04, 2021 at 12:19 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ultimez`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `uid` int(10) NOT NULL AUTO_INCREMENT,
  `ufullname` varchar(100) NOT NULL,
  `uemail` varchar(100) NOT NULL,
  `uphone` varchar(100) NOT NULL,
  `upassword` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `data_and_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `uphone` (`uphone`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `ufullname`, `uemail`, `uphone`, `upassword`, `username`, `data_and_time`, `last_login`) VALUES
(30, 'Zaid Reshamwale ', 'zaidreshamwale@gmail.com', '9035486843', 'Zaid@9035', 'zaidreshamwale', '2021-02-04 15:18:30', '2021-02-04 15:22:29'),
(31, 'MohammedZaid S Reshamwale', 'zaidreshamwale@yahoo.com', '9035486842', 'Zaid@123', 'zaidreshamwale', '2021-02-04 15:51:18', '2021-02-04 15:51:18'),
(32, 'MohammedZaid S Reshamwale', 'zaidreshamwale@yahoo.scom', '9035486857', 'Zuygdhd4', 'zaidreshamwale', '2021-02-04 15:52:13', '2021-02-04 15:52:13'),
(33, 'Xavi', 'xavi@yahoo.com', '9035484321', 'Zaid@123', 'xavi', '2021-02-04 16:36:18', '2021-02-04 16:36:18'),
(35, 'Messi', 'messi@yahoo.com', '9742175254', 'Zaid@9035', 'messi', '2021-02-04 17:17:05', '2021-02-04 17:17:05');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
