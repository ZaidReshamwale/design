<?php 
session_start();
// echo "<pre>";
// print_r($_SESSION['User']);
// echo "</pre>";
include ("nav.php");


?>
<?php
if (isset($_SESSION['User']))
{?>

<!DOCTYPE html>
<html>
<head>

	<title>User Page</title>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital@1&display=swap" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<style >
body{
		font-family: 'Josefin Sans', sans-serif;
		background: linear-gradient(rgba(0, 0, 50, 0.5),rgba(0, 0, 50, 0.5)),url(log.jpg);
	background-size: cover;
	background-position: center;background-color: ;

	}
.card {
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.3s;
  width: 30%;
  margin: 0 auto; /* Added */
        float: none; /* Added */
        margin-bottom: 10px; /* Added */
}

.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

.container {
  padding: 2px 16px;
}

</style>
</head>

<nav class="navbar navbar-light bg-light justify-content-between">
  <a class="navbar-brand"></a>
  <form class="form-inline">
  
  </form>
</nav>
<body>

<br>
<h1>Welcome <span style="color: #F13232;font-weight: bold"><?php echo $_SESSION['User']['ufullname']; ?></span></h1><br>


<div class="card">
  <img src="avatar.png" alt="Avatar" style="width:100%; height: 400px;">
  <div class="container">
    <h4><b>FullName: </b> <span style="color: #00004d;font-weight: bold"> <?php echo $_SESSION['User']['ufullname']; ?> </span></h4> </br>
    <h4><b>Email: </b> <span style="color: #00004d;font-weight: bold"> <?php echo $_SESSION['User']['uemail']; ?> </span></h4> </br>
    <h4><b>Phone.NO: </b> <span style="color: #00004d;font-weight: bold"> <?php echo $_SESSION['User']['uphone']; ?> </span></h4> </br>
    <h4><b>UserName: </b> <span style="color: #00004d;font-weight: bold"> <?php echo $_SESSION['User']['username']; ?> </span></h4> </br> 
  </div>
</div>

</body>
</html>

     <?php } else {
                                    ?>   <script>
                                    location.href = "../index.php";
                                    </script>
                                <?php } ?>